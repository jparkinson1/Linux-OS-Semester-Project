#!/bin/bash
#Semester Project
#coded by:Joshua Parkinson

#exits if there is any error
set -e

#uses given parameters to download necessary file
scp -r $1@$2:$3 $4

#extracts the file
bzip2 -d MOCK_MIX_v2.1.csv.bz2

#removes the header
sed -i '1d' MOCK_MIX_v2.1.csv

#makes all letters lowercase
sed -i 's/[A-Z]/\L&/g' MOCK_MIX_v2.1.csv

#finds instances of female and replaces it with f
sed -i 's/,female,/,f,/g' MOCK_MIX_v2.1.csv

#finds instances of male and replaces it with m
sed -i 's/,male,/,m,/g' MOCK_MIX_v2.1.csv

#finds instances of ,1, and replaces it with ,f,
sed -i 's/,1,/,f,/g' MOCK_MIX_v2.1.csv

#finds instances of ,0, and replaces it with ,m,
sed -i 's/,0,/,m,/g' MOCK_MIX_v2.1.csv

#finds instances of a blank in column 5 and replaces it with u
awk -F ',' 'BEGIN {FS=OFS=","};{if($5=="")$5="u"; print}' MOCK_MIX_v2.1.csv > MOCK.tmp && mv MOCK.tmp MOCK_MIX_v2.1.csv

#finds instances of blanks in column 12 and prints it to the exceptions.csv file
awk -F ',' '{if ($12=="") print $0 > "exceptions.csv"}' MOCK_MIX_v2.1.csv

#finds what is in exceptions.csv and removes those lines from MOCK_MIX_v2.1.csv
comm -23 <(sort MOCK_MIX_v2.1.csv) <(sort exceptions.csv) > testfile && mv testfile MOCK_MIX_v2.1.csv

#removes $ from column 6
cat MOCK_MIX_v2.1.csv|tr -d $ > testfile && mv testfile MOCK_MIX_v2.1.csv

#sorts by userid and sends output to transaction.csv
sort -t ',' -k1n MOCK_MIX_v2.1.csv > transaction.csv

#prints columns 1-3,6,12-13 to summary.csv
awk -F ',' 'BEGIN {FS=OFS=","};{ print $1,$2,$3,$6,$12,$13}' transaction.csv > summary.csv

#prints columns 1-3,5-6,12-13 to gender_summary.csv
awk -F ',' 'BEGIN {FS=OFS=","};{ print $1,$2,$3,$5,$6,$12,$13}' transaction.csv > gender_summary.csv

#sorts summary.csv by priority in the following order: state, zip, lastname, firstname
sort -t ',' -k5 -k6n -k3 -k2 summary.csv > summary.tmp && mv summary.tmp summary.csv

#sorts gender_summary.csv by priority in the following order: state, zip, lastname, firstname
sort -t ',' -k6 -k7n -k3 -k2 gender_summary.csv > summary.tmp && mv summary.tmp gender_summary.csv

#function to create transaction report
transaction_report='BEGIN{
		FS=OFS=",";

	       	#Declaring all variables to be used
		AK=0; 
		AL=0; 
		AR=0;
		AZ=0;
		CA=0;
		CO=0;
		CT=0;
		DC=0;
		DE=0;
		FL=0;
		GA=0;
		HI=0;
		IA=0;
		ID=0;
		IL=0;
		IN=0;
		KS=0;
		KY=0;
		LA=0;
		MA=0;
		MD=0;
		MI=0;
		MN=0;
		MO=0;
		MS=0;
		MT=0;
		NC=0;
		ND=0;
		NE=0;
		NH=0;
		NJ=0;
		NM=0;
		NV=0;
		NY=0;
		OH=0;
		OK=0;
		OR=0;
		PA=0;
		SC=0;
		SD=0;
		TN=0;
		TX=0;
		UT=0;
		VA=0;
		VT=0;
		WA=0;
		WI=0;
		WV=0;
}
{
		#conditions for the counter to add to a variable
		if ($5=="ak") AK+=1;
		if ($5=="al") AL+=1;
		if ($5=="ar") AR+=1;
		if ($5=="az") AZ+=1;
		if ($5=="ca") CA+=1;
		if ($5=="co") CO+=1;
		if ($5=="ct") CT+=1;
		if ($5=="dc") DC+=1;
		if ($5=="de") DE+=1;
		if ($5=="fl") FL+=1;
		if ($5=="ga") GA+=1;
		if ($5=="hi") HI+=1;
		if ($5=="ia") IA+=1;
		if ($5=="id") ID+=1;
		if ($5=="il") IL+=1;
		if ($5=="in") IN+=1;
		if ($5=="ks") KS+=1;
		if ($5=="ky") KY+=1;
		if ($5=="la") LA+=1;
		if ($5=="ma") MA+=1;
		if ($5=="md") MD+=1;
		if ($5=="mi") MI+=1;
		if ($5=="mn") MN+=1;
		if ($5=="mo") MO+=1;
		if ($5=="ms") MS+=1;
		if ($5=="mt") MT+=1;
		if ($5=="nc") NC+=1;
		if ($5=="nd") ND+=1;
		if ($5=="ne") NE+=1;
		if ($5=="nh") NH+=1;
		if ($5=="nj") NJ+=1;
		if ($5=="nm") NM+=1;
		if ($5=="nv") NV+=1;
		if ($5=="ny") NY+=1;
		if ($5=="oh") OH+=1;
		if ($5=="ok") OK+=1;
		if ($5=="or") OR+=1;
		if ($5=="pa") PA+=1;
		if ($5=="sc") SC+=1;
		if ($5=="sd") SD+=1;
		if ($5=="tn") TN+=1;
		if ($5=="tx") TX+=1;
		if ($5=="ut") UT+=1;
		if ($5=="va") VA+=1;
		if ($5=="vt") VT+=1;
		if ($5=="wa") WA+=1;
		if ($5=="wi") WI+=1;
		if ($5=="wv") WV+=1;
}
END{
	#constructing title of transaction.rpt
	printf "Report by: Joshua Parkinson""\n" > "transaction.rpt";
	printf "Transaction Count Report""\n" > "transaction.rpt";
	printf "State""\t""Transaction Count""\n" > "transaction.rpt";

	#constructing a csv file temp for constructing the data for transaction.rpt
	printf "AK"","AK"\n" > "temp";
	printf "AL"","AL"\n" > "temp";
	printf "AR"","AR"\n" > "temp";
	printf "AZ"","AZ"\n" > "temp";
	printf "CA"","CA"\n" > "temp";
	printf "CO"","CO"\n" > "temp";
	printf "CT"","CT"\n" > "temp";
	printf "DC"","DC"\n" > "temp";
	printf "DE"","DE"\n" > "temp";
	printf "FL"","FL"\n" > "temp";
	printf "GA"","GA"\n" > "temp";
	printf "HI"","HI"\n" > "temp";
	printf "IA"","IA"\n" > "temp";
	printf "ID"","ID"\n" > "temp";
	printf "IL"","IL"\n" > "temp";
	printf "IN"","IN"\n" > "temp";
	printf "KS"","KS"\n" > "temp";
	printf "KY"","KY"\n" > "temp";
	printf "LA"","LA"\n" > "temp";
	printf "MA"","MA"\n" > "temp";
	printf "MD"","MD"\n" > "temp";
	printf "MI"","MI"\n" > "temp";
	printf "MN"","MN"\n" > "temp";
	printf "MO"","MO"\n" > "temp";
	printf "MS"","MS"\n" > "temp";
	printf "MT"","MT"\n" > "temp";
	printf "NC"","NC"\n" > "temp";
	printf "ND"","ND"\n" > "temp";
	printf "NE"","NE"\n" > "temp";
	printf "NH"","NH"\n" > "temp";
	printf "NJ"","NJ"\n" > "temp";
	printf "NM"","NM"\n" > "temp";
	printf "NV"","NV"\n" > "temp";
	printf "NY"","NY"\n" > "temp";
	printf "OH"","OH"\n" > "temp";
	printf "OK"","OK"\n" > "temp";
	printf "OR"","OR"\n" > "temp";
	printf "PA"","PA"\n" > "temp";
	printf "SC"","SC"\n" > "temp";
	printf "SD"","SD"\n" > "temp";
	printf "TN"","TN"\n" > "temp";
	printf "TX"","TX"\n" > "temp";
	printf "UT"","UT"\n" > "temp";
	printf "VA"","VA"\n" > "temp";
	printf "VT"","VT"\n" > "temp";
	printf "WA"","WA"\n" > "temp";
	printf "WI"","WI"\n" > "temp";
	printf "WV"","WV"\n\n" > "temp";
}' 

#calls function to construct transaction.rpt and temp
awk "$transaction_report" summary.csv

#sorts temp by number of transactions and then by state. priority is in that order.
sort -t "," -k2,2rn -k1 temp > temp2 && mv temp2 temp

#finds commas in temp and replaces them with tab
sed -i 's/,/\t/g' temp

#appends transaction.rpt with the cat of temp
cat temp >> transaction.rpt

#displays report
cat transaction.rpt

#function to construct purchase.rpt
purchase_report='BEGIN{
	FS=OFS=",";

	#declaring all variables to be used
	AKm=0;AKf=0;
	ALm=0;ALf=0;
	ARm=0;ARf=0;
	AZm=0;AZf=0;
	CAm=0;CAf=0;
	COm=0;COf=0;
	CTm=0;CTf=0;
	DCm=0;DCf=0;
	DEm=0;DEf=0;
	FLm=0;FLf=0;
	GAm=0;GAf=0;
	HIm=0;HIf=0;
	IAm=0;IAf=0;
	IDm=0;IDf=0;
	ILm=0;ILf=0;
	INm=0;INf=0;
	KSm=0;KSf=0;
	KYm=0;KYf=0;
	LAm=0;LAf=0;
	MAm=0;MAf=0;
	MDm=0;MDf=0;
	MIm=0;MIf=0;
	MNm=0;MNf=0;
	MOm=0;MOf=0;
	MSm=0;MSf=0;
	MTm=0;MTf=0;
	NCm=0;NCf=0;
	NDm=0;NDf=0;
	NEm=0;NEf=0;
	NHm=0;NHf=0;
	NJm=0;NJf=0;
	NMm=0;NMf=0;
	NVm=0;NVf=0;
	NYm=0;NYf=0;
	OHm=0;OHf=0;
	OKm=0;OKf=0;
	ORm=0;ORf=0;
	PAm=0;PAf=0;
	SCm=0;SCf=0;
	SDm=0;SDf=0;
	TNm=0;TNf=0;
	TXm=0;TXf=0;
	UTm=0;UTf=0;
	VAm=0;VAf=0;
	VTm=0;VTf=0;
	WAm=0;WAf=0;
	WIm=0;WIf=0;
	WVm=0;WVf=0;
}
{
	#Conditions for counters to add to a variable
	if ($6=="ak" && $4=="m") AKm+=$5; if ($6=="ak" && $4=="f") AKf+=$5;
	if ($6=="al" && $4=="m") ALm+=$5; if ($6=="al" && $4=="f") ALf+=$5;
	if ($6=="ar" && $4=="m") ARm+=$5; if ($6=="ar" && $4=="f") ARf+=$5;
	if ($6=="az" && $4=="m") AZm+=$5; if ($6=="az" && $4=="f") AZf+=$5;
	if ($6=="ca" && $4=="m") CAm+=$5; if ($6=="ca" && $4=="f") CAf+=$5;
	if ($6=="co" && $4=="m") COm+=$5; if ($6=="co" && $4=="f") COf+=$5;
	if ($6=="ct" && $4=="m") CTm+=$5; if ($6=="ct" && $4=="f") CTf+=$5;
	if ($6=="dc" && $4=="m") DCm+=$5; if ($6=="dc" && $4=="f") DCf+=$5;
	if ($6=="de" && $4=="m") DEm+=$5; if ($6=="de" && $4=="f") DEf+=$5;
	if ($6=="fl" && $4=="m") FLm+=$5; if ($6=="fl" && $4=="f") FLf+=$5;
	if ($6=="ga" && $4=="m") GAm+=$5; if ($6=="ga" && $4=="f") GAf+=$5;
	if ($6=="hi" && $4=="m") HIm+=$5; if ($6=="hi" && $4=="f") HIf+=$5;
	if ($6=="ia" && $4=="m") IAm+=$5; if ($6=="ia" && $4=="f") IAf+=$5;
	if ($6=="id" && $4=="m") IDm+=$5; if ($6=="id" && $4=="f") IDf+=$5;
	if ($6=="il" && $4=="m") ILm+=$5; if ($6=="il" && $4=="f") ILf+=$5;
	if ($6=="in" && $4=="m") INm+=$5; if ($6=="in" && $4=="f") INf+=$5;
	if ($6=="ks" && $4=="m") KSm+=$5; if ($6=="ks" && $4=="f") KSf+=$5;
	if ($6=="ky" && $4=="m") KYm+=$5; if ($6=="ky" && $4=="f") KYf+=$5;
	if ($6=="la" && $4=="m") LAm+=$5; if ($6=="la" && $4=="f") LAf+=$5;
	if ($6=="ma" && $4=="m") MAm+=$5; if ($6=="ma" && $4=="f") MAf+=$5;
	if ($6=="md" && $4=="m") MDm+=$5; if ($6=="md" && $4=="f") MDf+=$5;
	if ($6=="mi" && $4=="m") MIm+=$5; if ($6=="mi" && $4=="f") MIf+=$5;
	if ($6=="mn" && $4=="m") MNm+=$5; if ($6=="mn" && $4=="f") MNf+=$5;
	if ($6=="mo" && $4=="m") MOm+=$5; if ($6=="mo" && $4=="f") MOf+=$5;
	if ($6=="ms" && $4=="m") MSm+=$5; if ($6=="ms" && $4=="f") MSf+=$5;
	if ($6=="mt" && $4=="m") MTm+=$5; if ($6=="mt" && $4=="f") MTf+=$5;
	if ($6=="nc" && $4=="m") NCm+=$5; if ($6=="nc" && $4=="f") NCf+=$5;
	if ($6=="nd" && $4=="m") NDm+=$5; if ($6=="nd" && $4=="f") NDf+=$5;
	if ($6=="ne" && $4=="m") NEm+=$5; if ($6=="ne" && $4=="f") NEf+=$5;
	if ($6=="nh" && $4=="m") NHm+=$5; if ($6=="nh" && $4=="f") NHf+=$5;
	if ($6=="nj" && $4=="m") NJm+=$5; if ($6=="nj" && $4=="f") NJf+=$5;
	if ($6=="nm" && $4=="m") NMm+=$5; if ($6=="nm" && $4=="f") NMf+=$5;
	if ($6=="nv" && $4=="m") NVm+=$5; if ($6=="nv" && $4=="f") NVf+=$5;
	if ($6=="ny" && $4=="m") NYm+=$5; if ($6=="ny" && $4=="f") NYf+=$5;
	if ($6=="oh" && $4=="m") OHm+=$5; if ($6=="oh" && $4=="f") OHf+=$5;
	if ($6=="ok" && $4=="m") OKm+=$5; if ($6=="ok" && $4=="f") OKf+=$5;
	if ($6=="or" && $4=="m") ORm+=$5; if ($6=="or" && $4=="f") ORf+=$5;
	if ($6=="pa" && $4=="m") PAm+=$5; if ($6=="pa" && $4=="f") PAf+=$5;
	if ($6=="sc" && $4=="m") SCm+=$5; if ($6=="sc" && $4=="f") SCf+=$5;
	if ($6=="sd" && $4=="m") SDm+=$5; if ($6=="sd" && $4=="f") SDf+=$5;
	if ($6=="tn" && $4=="m") TNm+=$5; if ($6=="tn" && $4=="f") TNf+=$5;
	if ($6=="tx" && $4=="m") TXm+=$5; if ($6=="tx" && $4=="f") TXf+=$5;
	if ($6=="ut" && $4=="m") UTm+=$5; if ($6=="ut" && $4=="f") UTf+=$5;
	if ($6=="va" && $4=="m") VAm+=$5; if ($6=="va" && $4=="f") VAf+=$5;
	if ($6=="vt" && $4=="m") VTm+=$5; if ($6=="vt" && $4=="f") VTf+=$5;
	if ($6=="wa" && $4=="m") WAm+=$5; if ($6=="wa" && $4=="f") WAf+=$5;
	if ($6=="wi" && $4=="m") WIm+=$5; if ($6=="wi" && $4=="f") WIf+=$5;
	if ($6=="wv" && $4=="m") WVm+=$5; if ($6=="wv" && $4=="f") WVf+=$5;
}
END{
	#title and construction of the purchase.rpt
	printf "Report by: Joshua Parkinson""\n" > "purchase.rpt";
	printf "Purchase Summary Report""\n" > "purchase.rpt";
	printf "State""\t""Gender""\t""Report""\n" > "purchase.rpt";

	#prints data to construct purchase.rpt to a csv called gender.tmp
	printf "AK"",""M"",%5.2f""\n", AKm > "gender.tmp"; printf "AK"",""F"",%5.2f""\n", AKf > "gender.tmp";
	printf "AL"",""M"",%5.2f""\n", ALm > "gender.tmp"; printf "AL"",""F"",%5.2f""\n", ALf > "gender.tmp";
	printf "AR"",""M"",%5.2f""\n", ARm > "gender.tmp"; printf "AR"",""F"",%5.2f""\n", ARf > "gender.tmp";
	printf "AZ"",""M"",%5.2f""\n", AZm > "gender.tmp"; printf "AZ"",""F"",%5.2f""\n", AZf > "gender.tmp";
	printf "CA"",""M"",%5.2f""\n", CAm > "gender.tmp"; printf "CA"",""F"",%5.2f""\n", CAf > "gender.tmp";
	printf "CO"",""M"",%5.2f""\n", COm > "gender.tmp"; printf "CO"",""F"",%5.2f""\n", COf > "gender.tmp";
	printf "CT"",""M"",%5.2f""\n", CTm > "gender.tmp"; printf "CT"",""F"",%5.2f""\n", CTf > "gender.tmp";
	printf "DC"",""M"",%5.2f""\n", DCm > "gender.tmp"; printf "DC"",""F"",%5.2f""\n", DCf > "gender.tmp";
	printf "DE"",""M"",%5.2f""\n", DEm > "gender.tmp"; printf "DE"",""F"",%5.2f""\n", DEf > "gender.tmp";
	printf "FL"",""M"",%5.2f""\n", FLm > "gender.tmp"; printf "FL"",""F"",%5.2f""\n", FLf > "gender.tmp";
	printf "GA"",""M"",%5.2f""\n", GAm > "gender.tmp"; printf "GA"",""F"",%5.2f""\n", GAf > "gender.tmp";
	printf "HI"",""M"",%5.2f""\n", HIm > "gender.tmp"; printf "HI"",""F"",%5.2f""\n", HIf > "gender.tmp";
	printf "IA"",""M"",%5.2f""\n", FLm > "gender.tmp"; printf "IA"",""F"",%5.2f""\n", IAf > "gender.tmp";
	printf "ID"",""M"",%5.2f""\n", IDm > "gender.tmp"; printf "ID"",""F"",%5.2f""\n", IDf > "gender.tmp";
	printf "IL"",""M"",%5.2f""\n", ILm > "gender.tmp"; printf "IL"",""F"",%5.2f""\n", ILf > "gender.tmp";
	printf "IN"",""M"",%5.2f""\n", INm > "gender.tmp"; printf "IN"",""F"",%5.2f""\n", INf > "gender.tmp";
	printf "KS"",""M"",%5.2f""\n", KSm > "gender.tmp"; printf "KS"",""F"",%5.2f""\n", KSf > "gender.tmp";
	printf "KY"",""M"",%5.2f""\n", KYm > "gender.tmp"; printf "KY"",""F"",%5.2f""\n", KYf > "gender.tmp";
	printf "LA"",""M"",%5.2f""\n", LAm > "gender.tmp"; printf "LA"",""F"",%5.2f""\n", LAf > "gender.tmp";
	printf "MA"",""M"",%5.2f""\n", MAm > "gender.tmp"; printf "MA"",""F"",%5.2f""\n", MAf > "gender.tmp";
	printf "MD"",""M"",%5.2f""\n", MDm > "gender.tmp"; printf "MD"",""F"",%5.2f""\n", MDf > "gender.tmp";
	printf "MI"",""M"",%5.2f""\n", MIm > "gender.tmp"; printf "MI"",""F"",%5.2f""\n", MIf > "gender.tmp";
	printf "MN"",""M"",%5.2f""\n", MNm > "gender.tmp"; printf "MN"",""F"",%5.2f""\n", MNf > "gender.tmp";
	printf "MO"",""M"",%5.2f""\n", MOm > "gender.tmp"; printf "MO"",""F"",%5.2f""\n", MOf > "gender.tmp";
	printf "MS"",""M"",%5.2f""\n", MSm > "gender.tmp"; printf "MS"",""F"",%5.2f""\n", MSf > "gender.tmp";
	printf "MT"",""M"",%5.2f""\n", MTm > "gender.tmp"; printf "MT"",""F"",%5.2f""\n", MTf > "gender.tmp";
	printf "NC"",""M"",%5.2f""\n", NCm > "gender.tmp"; printf "NC"",""F"",%5.2f""\n", NCf > "gender.tmp";
	printf "ND"",""M"",%5.2f""\n", NDm > "gender.tmp"; printf "ND"",""F"",%5.2f""\n", NDf > "gender.tmp";
	printf "NE"",""M"",%5.2f""\n", NEm > "gender.tmp"; printf "NE"",""F"",%5.2f""\n", NEf > "gender.tmp";
	printf "NH"",""M"",%5.2f""\n", NHm > "gender.tmp"; printf "NH"",""F"",%5.2f""\n", NHf > "gender.tmp";
	printf "NJ"",""M"",%5.2f""\n", NJm > "gender.tmp"; printf "NJ"",""F"",%5.2f""\n", NJf > "gender.tmp";
	printf "NM"",""M"",%5.2f""\n", NMm > "gender.tmp"; printf "NM"",""F"",%5.2f""\n", NMf > "gender.tmp";
	printf "NV"",""M"",%5.2f""\n", NVm > "gender.tmp"; printf "NV"",""F"",%5.2f""\n", NVf > "gender.tmp";
	printf "NY"",""M"",%5.2f""\n", NYm > "gender.tmp"; printf "NY"",""F"",%5.2f""\n", NYf > "gender.tmp";
	printf "OH"",""M"",%5.2f""\n", OHm > "gender.tmp"; printf "OH"",""F"",%5.2f""\n", OHf > "gender.tmp";
	printf "OK"",""M"",%5.2f""\n", OKm > "gender.tmp"; printf "OK"",""F"",%5.2f""\n", OKf > "gender.tmp";
	printf "OR"",""M"",%5.2f""\n", ORm > "gender.tmp"; printf "OR"",""F"",%5.2f""\n", ORf > "gender.tmp";
	printf "PA"",""M"",%5.2f""\n", PAm > "gender.tmp"; printf "PA"",""F"",%5.2f""\n", PAf > "gender.tmp";
	printf "SC"",""M"",%5.2f""\n", SCm > "gender.tmp"; printf "SC"",""F"",%5.2f""\n", SCf > "gender.tmp";
	printf "SD"",""M"",%5.2f""\n", SDm > "gender.tmp"; printf "SD"",""F"",%5.2f""\n", SDf > "gender.tmp";
	printf "TN"",""M"",%5.2f""\n", TNm > "gender.tmp"; printf "TN"",""F"",%5.2f""\n", TNf > "gender.tmp";
	printf "TX"",""M"",%5.2f""\n", TXm > "gender.tmp"; printf "TX"",""F"",%5.2f""\n", TXf > "gender.tmp";
	printf "UT"",""M"",%5.2f""\n", UTm > "gender.tmp"; printf "UT"",""F"",%5.2f""\n", UTf > "gender.tmp";
	printf "VA"",""M"",%5.2f""\n", VAm > "gender.tmp"; printf "VA"",""F"",%5.2f""\n", VAf > "gender.tmp";
	printf "VT"",""M"",%5.2f""\n", VTm > "gender.tmp"; printf "VT"",""F"",%5.2f""\n", VTf > "gender.tmp";
	printf "WA"",""M"",%5.2f""\n", WAm > "gender.tmp"; printf "WA"",""F"",%5.2f""\n", WAf > "gender.tmp";
	printf "WI"",""M"",%5.2f""\n", WIm > "gender.tmp"; printf "WI"",""F"",%5.2f""\n", WIf > "gender.tmp";
	printf "WV"",""M"",%5.2f""\n", WVm > "gender.tmp"; printf "WV"",""F"",%5.2f""\n", WVf > "gender.tmp";
}'

#calls purchase_report function
awk "$purchase_report" gender_summary.csv

#sorts by purchase amount and then by state in that priority order
sort -t "," -k3,3rn -k1 gender.tmp > gender.tmp2 && mv gender.tmp2 gender.tmp

#removes commas from csv replacing them with tabs
sed -i 's/,/\t/g' gender.tmp

#output of cat gender.tmp sent to purchase.rpt
cat gender.tmp >> purchase.rpt

#displays purchase.rpt
cat purchase.rpt

#removing temporary files
rm MOCK_MIX_v2.1.csv
rm temp
rm gender.tmp
rm gender_summary.csv
