How to use:

example:
./etl.sh jparkinson1 40.69.135.45 /home/shared/MOCK_MIX_v2.1.csv.bz2 ~/semesterProject

explanation:
./etl.sh -- file to execute
jparkinson1 -- username
40.69.135.45 -- ip address of server
/home/shared/MOCK_MIX_v2.1.csv.bz2 -- filepath of file to be downloaded
~/semesterProject -- filepath to download file to
